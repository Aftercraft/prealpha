package net.mcreator.aftercraftcore.procedures;

public class KilnFuelScriptProcedure {
	public static void execute() {
	}
}
